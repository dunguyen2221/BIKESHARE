using BikeShareWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BikeShareWebApp.Controllers;

public class IssueController : Controller
{
    private readonly BikeShareDbContext _context;

    public IssueController(BikeShareDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> Create(int? bikeId)
    {
        int? userId = HttpContext.Session.GetInt32("UserId");
        if (userId == null)
        {
            TempData["Error"] = "Bạn cần đăng nhập để báo hỏng xe.";
            return RedirectToAction("Login", "Account");
        }

        ViewBag.Bikes = await _context.Bikes
            .OrderBy(b => b.BikeCode)
            .ToListAsync();

        var currentTrip = await _context.Trips
            .FirstOrDefaultAsync(t => t.CustomerId == userId && 
                (t.TripStatus == "Active" || t.TripStatus == "Paused"));

        var model = new IssueReport
        {
            CustomerId = userId.Value,
            BikeId = bikeId ?? currentTrip?.BikeId ?? 0,
            TripId = currentTrip?.TripId,
            IssueType = "Khóa xe",
            ReportStatus = "New"
        };

        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(IssueReport model)
    {
        int? userId = HttpContext.Session.GetInt32("UserId");
        if (userId == null)
        {
            return RedirectToAction("Login", "Account");
        }

        if (model.BikeId <= 0 || string.IsNullOrWhiteSpace(model.IssueType) || string.IsNullOrWhiteSpace(model.Description))
        {
            TempData["Error"] = "Vui lòng chọn xe, loại sự cố và nhập mô tả.";
            ViewBag.Bikes = await _context.Bikes.OrderBy(b => b.BikeCode).ToListAsync();
            return View(model);
        }

        var bike = await _context.Bikes.FirstOrDefaultAsync(b => b.BikeId == model.BikeId);
        if (bike == null)
        {
            TempData["Error"] = "Không tìm thấy xe.";
            return RedirectToAction("Map", "Bike");
        }

        var activeTrip = await _context.Trips
            .FirstOrDefaultAsync(t => t.CustomerId == userId && t.BikeId == model.BikeId &&
                (t.TripStatus == "Active" || t.TripStatus == "Paused"));

        var issue = new IssueReport
        {
            CustomerId = userId.Value,
            BikeId = model.BikeId,
            TripId = activeTrip?.TripId,
            IssueType = model.IssueType.Trim(),
            Description = model.Description.Trim(),
            ImageUrl = model.ImageUrl,
            ReportStatus = "New",
            CreatedAt = DateTime.Now
        };

        bike.BikeStatus = "Issue";

        var maintenance = new MaintenanceTicket
        {
            BikeId = bike.BikeId,
            Description = $"Tự động tạo từ báo cáo sự cố: {issue.IssueType}",
            MaintenanceStatus = "Open",
            CreatedAt = DateTime.Now
        };

        _context.IssueReports.Add(issue);
        await _context.SaveChangesAsync();

        maintenance.IssueReportId = issue.IssueReportId;
        _context.MaintenanceTickets.Add(maintenance);

        await _context.SaveChangesAsync();

        TempData["Success"] = "Đã gửi báo cáo sự cố. Nhân viên kỹ thuật sẽ xử lý.";
        return RedirectToAction("Map", "Bike");
    }
}

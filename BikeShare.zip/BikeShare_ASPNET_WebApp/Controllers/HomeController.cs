using BikeShareWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BikeShareWebApp.Controllers;

public class HomeController : Controller
{
    private readonly BikeShareDbContext _context;

    public HomeController(BikeShareDbContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Index()
    {
        ViewBag.BikeCount = await _context.Bikes.CountAsync();
        ViewBag.StationCount = await _context.Stations.CountAsync();
        ViewBag.AvailableBikeCount = await _context.Bikes.CountAsync(b => b.BikeStatus == "Available");

        return View();
    }
}

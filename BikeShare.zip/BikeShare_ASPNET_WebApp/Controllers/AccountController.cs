using BikeShareWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BikeShareWebApp.Controllers;

public class AccountController : Controller
{
    private readonly BikeShareDbContext _context;

    public AccountController(BikeShareDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public IActionResult Login()
    {
        if (HttpContext.Session.GetInt32("UserId") != null)
        {
            string roleName = HttpContext.Session.GetString("RoleName") ?? string.Empty;

            if (roleName.Equals("Admin", StringComparison.OrdinalIgnoreCase))
            {
                return RedirectToAction("Dashboard", "Admin");
            }

            return RedirectToAction("Index", "Home");
        }

        return View(new LoginViewModel());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        string username = model.Username.Trim();
        string password = model.Password.Trim();

        var user = await _context.Users
            .Include(u => u.Role)
            .FirstOrDefaultAsync(u => u.Phone == username || u.Email == username);

        if (user == null || !IsPasswordValid(user.PasswordHash, password))
        {
            ModelState.AddModelError("", "Tài khoản hoặc mật khẩu không đúng.");
            return View(model);
        }

        if (!user.Status.Equals("Active", StringComparison.OrdinalIgnoreCase))
        {
            ModelState.AddModelError("", "Tài khoản đang bị khóa hoặc chưa được kích hoạt.");
            return View(model);
        }

        string roleName = user.Role?.RoleName ?? string.Empty;

        HttpContext.Session.SetInt32("UserId", user.UserId);
        HttpContext.Session.SetString("FullName", user.FullName);
        HttpContext.Session.SetString("RoleName", roleName);
        HttpContext.Session.SetString("Email", user.Email ?? string.Empty);
        HttpContext.Session.SetString("Phone", user.Phone);

        TempData["Success"] = $"Đăng nhập thành công. Xin chào {user.FullName}!";

        if (roleName.Equals("Admin", StringComparison.OrdinalIgnoreCase))
        {
            return RedirectToAction("Dashboard", "Admin");
        }

        return RedirectToAction("Index", "Home");
    }

    [HttpGet]
    public IActionResult Register()
    {
        if (HttpContext.Session.GetInt32("UserId") != null)
        {
            return RedirectToAction("Index", "Home");
        }

        return View(new RegisterViewModel());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        string fullName = model.FullName.Trim();
        string phone = model.Phone.Trim();
        string? email = string.IsNullOrWhiteSpace(model.Email) ? null : model.Email.Trim();

        bool phoneExists = await _context.Users.AnyAsync(u => u.Phone == phone);

        if (phoneExists)
        {
            ModelState.AddModelError(nameof(model.Phone), "Số điện thoại đã được sử dụng.");
            return View(model);
        }

        if (!string.IsNullOrWhiteSpace(email))
        {
            bool emailExists = await _context.Users.AnyAsync(u => u.Email == email);

            if (emailExists)
            {
                ModelState.AddModelError(nameof(model.Email), "Email đã được sử dụng.");
                return View(model);
            }
        }

        var customerRole = await _context.Roles
            .FirstOrDefaultAsync(r => r.RoleName == "Customer");

        if (customerRole == null)
        {
            ModelState.AddModelError("", "Database chưa có vai trò Customer. Vui lòng chạy lại file SQL tạo database.");
            return View(model);
        }

        var user = new User
        {
            RoleId = customerRole.RoleId,
            FullName = fullName,
            Phone = phone,
            Email = email,
            PasswordHash = model.Password.Trim(), // Demo đồ án: lưu trực tiếp. Thực tế cần mã hóa mật khẩu.
            Status = "Active",
            CreatedAt = DateTime.Now
        };

        _context.Users.Add(user);
        await _context.SaveChangesAsync();

        var profile = new CustomerProfile
        {
            CustomerId = user.UserId,
            VerifiedStatus = "NotVerified"
        };

        var wallet = new Wallet
        {
            CustomerId = user.UserId,
            Balance = 0,
            UpdatedAt = DateTime.Now
        };

        _context.CustomerProfiles.Add(profile);
        _context.Wallets.Add(wallet);

        await _context.SaveChangesAsync();

        TempData["Success"] = "Đăng ký tài khoản thành công. Vui lòng đăng nhập.";
        return RedirectToAction("Login");
    }

    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        TempData["Success"] = "Bạn đã đăng xuất.";
        return RedirectToAction("Index", "Home");
    }

    private static bool IsPasswordValid(string storedPassword, string inputPassword)
    {
        if (storedPassword == inputPassword)
        {
            return true;
        }

        // Hỗ trợ dữ liệu mẫu cũ trong file SQL: 123456_HASH_DEMO, admin_HASH_DEMO, tech_HASH_DEMO
        if (storedPassword == $"{inputPassword}_HASH_DEMO")
        {
            return true;
        }

        if (storedPassword == "123456_HASH_DEMO" && inputPassword == "123456")
        {
            return true;
        }

        if (storedPassword == "admin_HASH_DEMO" && (inputPassword == "admin" || inputPassword == "admin123"))
        {
            return true;
        }

        if (storedPassword == "tech_HASH_DEMO" && (inputPassword == "tech" || inputPassword == "tech123"))
        {
            return true;
        }

        return false;
    }
}

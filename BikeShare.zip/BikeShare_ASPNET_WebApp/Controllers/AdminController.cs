using BikeShareWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BikeShareWebApp.Controllers;

public class AdminController : Controller
{
    private readonly BikeShareDbContext _context;

    public AdminController(BikeShareDbContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Dashboard()
    {
        if (!IsAdminUser()) return RequireAdmin();

        ViewBag.TotalUsers = await _context.Users.CountAsync();
        ViewBag.TotalBikes = await _context.Bikes.CountAsync();
        ViewBag.AvailableBikes = await _context.Bikes.CountAsync(b => b.BikeStatus == "Available");
        ViewBag.TotalTrips = await _context.Trips.CountAsync();
        ViewBag.ActiveTrips = await _context.Trips.CountAsync(t => t.TripStatus == "Active" || t.TripStatus == "Paused");
        ViewBag.OpenIssues = await _context.IssueReports.CountAsync(i => i.ReportStatus == "New" || i.ReportStatus == "Processing");
        ViewBag.Revenue = await _context.Payments
            .Where(p => p.PaymentStatus == "Success")
            .SumAsync(p => (decimal?)p.Amount) ?? 0;

        ViewBag.RecentTrips = await _context.Trips
            .Include(t => t.Customer)
            .Include(t => t.Bike)
            .OrderByDescending(t => t.StartTime)
            .Take(5)
            .ToListAsync();

        return View();
    }

    public async Task<IActionResult> Bikes()
    {
        if (!IsAdminUser()) return RequireAdmin();

        var bikes = await _context.Bikes
            .Include(b => b.Station)
            .OrderBy(b => b.BikeCode)
            .ToListAsync();

        return View(bikes);
    }

    [HttpGet]
    public async Task<IActionResult> BikeCreate()
    {
        if (!IsAdminUser()) return RequireAdmin();

        await LoadStationOptions();
        return View(new Bike { BikeStatus = "Available", QrCode = "QR-" });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> BikeCreate(Bike model)
    {
        if (!IsAdminUser()) return RequireAdmin();

        if (string.IsNullOrWhiteSpace(model.BikeCode) || string.IsNullOrWhiteSpace(model.QrCode))
        {
            TempData["Error"] = "Vui lòng nhập mã xe và mã QR.";
            await LoadStationOptions();
            return View(model);
        }

        bool exists = await _context.Bikes.AnyAsync(b => b.BikeCode == model.BikeCode || b.QrCode == model.QrCode);
        if (exists)
        {
            TempData["Error"] = "Mã xe hoặc QR đã tồn tại.";
            await LoadStationOptions();
            return View(model);
        }

        var bike = new Bike
        {
            BikeCode = model.BikeCode.Trim(),
            QrCode = model.QrCode.Trim(),
            StationId = model.StationId,
            BikeStatus = string.IsNullOrWhiteSpace(model.BikeStatus) ? "Available" : model.BikeStatus,
            CreatedAt = DateTime.Now
        };

        _context.Bikes.Add(bike);
        await _context.SaveChangesAsync();

        TempData["Success"] = "Đã thêm xe mới.";
        return RedirectToAction(nameof(Bikes));
    }

    [HttpGet]
    public async Task<IActionResult> BikeEdit(int id)
    {
        if (!IsAdminUser()) return RequireAdmin();

        var bike = await _context.Bikes.FindAsync(id);
        if (bike == null)
        {
            TempData["Error"] = "Không tìm thấy xe.";
            return RedirectToAction(nameof(Bikes));
        }

        await LoadStationOptions();
        return View(bike);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> BikeEdit(Bike model)
    {
        if (!IsAdminUser()) return RequireAdmin();

        var bike = await _context.Bikes.FindAsync(model.BikeId);
        if (bike == null)
        {
            TempData["Error"] = "Không tìm thấy xe.";
            return RedirectToAction(nameof(Bikes));
        }

        bike.BikeCode = model.BikeCode.Trim();
        bike.QrCode = model.QrCode.Trim();
        bike.StationId = model.StationId;
        bike.BikeStatus = model.BikeStatus;

        await _context.SaveChangesAsync();

        TempData["Success"] = "Đã cập nhật xe.";
        return RedirectToAction(nameof(Bikes));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> BikeStatus(int id, string status)
    {
        if (!IsAdminUser()) return RequireAdmin();

        var bike = await _context.Bikes.FindAsync(id);
        if (bike == null)
        {
            TempData["Error"] = "Không tìm thấy xe.";
            return RedirectToAction(nameof(Bikes));
        }

        bike.BikeStatus = status;
        await _context.SaveChangesAsync();

        TempData["Success"] = $"Đã đổi trạng thái xe {bike.BikeCode} thành {status}.";
        return RedirectToAction(nameof(Bikes));
    }

    public async Task<IActionResult> Stations()
    {
        if (!IsAdminUser()) return RequireAdmin();

        var stations = await _context.Stations
            .Include(s => s.Bikes)
            .OrderBy(s => s.StationCode)
            .ToListAsync();

        return View(stations);
    }

    [HttpGet]
    public IActionResult StationCreate()
    {
        if (!IsAdminUser()) return RequireAdmin();

        return View(new Station { Status = "Active", Capacity = 20 });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> StationCreate(Station model)
    {
        if (!IsAdminUser()) return RequireAdmin();

        if (string.IsNullOrWhiteSpace(model.StationCode) || string.IsNullOrWhiteSpace(model.StationName))
        {
            TempData["Error"] = "Vui lòng nhập mã trạm và tên trạm.";
            return View(model);
        }

        bool exists = await _context.Stations.AnyAsync(s => s.StationCode == model.StationCode);
        if (exists)
        {
            TempData["Error"] = "Mã trạm đã tồn tại.";
            return View(model);
        }

        model.CreatedAt = DateTime.Now;
        _context.Stations.Add(model);
        await _context.SaveChangesAsync();

        TempData["Success"] = "Đã thêm trạm mới.";
        return RedirectToAction(nameof(Stations));
    }

    [HttpGet]
    public async Task<IActionResult> StationEdit(int id)
    {
        if (!IsAdminUser()) return RequireAdmin();

        var station = await _context.Stations.FindAsync(id);
        if (station == null)
        {
            TempData["Error"] = "Không tìm thấy trạm.";
            return RedirectToAction(nameof(Stations));
        }

        return View(station);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> StationEdit(Station model)
    {
        if (!IsAdminUser()) return RequireAdmin();

        var station = await _context.Stations.FindAsync(model.StationId);
        if (station == null)
        {
            TempData["Error"] = "Không tìm thấy trạm.";
            return RedirectToAction(nameof(Stations));
        }

        station.StationCode = model.StationCode.Trim();
        station.StationName = model.StationName.Trim();
        station.Address = model.Address;
        station.Latitude = model.Latitude;
        station.Longitude = model.Longitude;
        station.Capacity = model.Capacity;
        station.Status = model.Status;

        await _context.SaveChangesAsync();

        TempData["Success"] = "Đã cập nhật trạm.";
        return RedirectToAction(nameof(Stations));
    }

    public async Task<IActionResult> Users()
    {
        if (!IsAdminUser()) return RequireAdmin();

        var users = await _context.Users
            .Include(u => u.Role)
            .OrderByDescending(u => u.CreatedAt)
            .ToListAsync();

        return View(users);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ToggleUserStatus(int id)
    {
        if (!IsAdminUser()) return RequireAdmin();

        var user = await _context.Users.FindAsync(id);
        if (user == null)
        {
            TempData["Error"] = "Không tìm thấy người dùng.";
            return RedirectToAction(nameof(Users));
        }

        int? currentAdminId = HttpContext.Session.GetInt32("UserId");
        if (currentAdminId == user.UserId)
        {
            TempData["Error"] = "Không thể tự khóa tài khoản Admin đang đăng nhập.";
            return RedirectToAction(nameof(Users));
        }

        user.Status = user.Status == "Active" ? "Locked" : "Active";
        await _context.SaveChangesAsync();

        TempData["Success"] = "Đã cập nhật trạng thái người dùng.";
        return RedirectToAction(nameof(Users));
    }

    public async Task<IActionResult> Trips()
    {
        if (!IsAdminUser()) return RequireAdmin();

        var trips = await _context.Trips
            .Include(t => t.Customer)
            .Include(t => t.Bike)
            .Include(t => t.StartStation)
            .Include(t => t.EndStation)
            .OrderByDescending(t => t.StartTime)
            .ToListAsync();

        return View(trips);
    }

    public async Task<IActionResult> Issues()
    {
        if (!IsAdminUser()) return RequireAdmin();

        var issues = await _context.IssueReports
            .Include(i => i.Customer)
            .Include(i => i.Bike)
            .Include(i => i.Trip)
            .OrderByDescending(i => i.CreatedAt)
            .ToListAsync();

        return View(issues);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> UpdateIssueStatus(int id, string status)
    {
        if (!IsAdminUser()) return RequireAdmin();

        var issue = await _context.IssueReports
            .Include(i => i.Bike)
            .FirstOrDefaultAsync(i => i.IssueReportId == id);

        if (issue == null)
        {
            TempData["Error"] = "Không tìm thấy báo cáo sự cố.";
            return RedirectToAction(nameof(Issues));
        }

        issue.ReportStatus = status;

        if (status == "Resolved" && issue.Bike != null)
        {
            issue.Bike.BikeStatus = "Available";

            var tickets = await _context.MaintenanceTickets
                .Where(t => t.IssueReportId == issue.IssueReportId && t.MaintenanceStatus != "Done")
                .ToListAsync();

            foreach (var ticket in tickets)
            {
                ticket.MaintenanceStatus = "Done";
                ticket.CompletedAt = DateTime.Now;
            }
        }

        await _context.SaveChangesAsync();

        TempData["Success"] = "Đã cập nhật trạng thái sự cố.";
        return RedirectToAction(nameof(Issues));
    }

    private async Task LoadStationOptions()
    {
        ViewBag.Stations = await _context.Stations
            .Where(s => s.Status == "Active")
            .OrderBy(s => s.StationName)
            .ToListAsync();
    }

    private bool IsAdminUser()
    {
        string roleName = HttpContext.Session.GetString("RoleName") ?? string.Empty;
        return roleName.Equals("Admin", StringComparison.OrdinalIgnoreCase);
    }

    private IActionResult RequireAdmin()
    {
        TempData["Error"] = "Bạn cần đăng nhập bằng tài khoản Admin để dùng chức năng này.";
        return RedirectToAction("Login", "Account");
    }
}

using BikeShareWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BikeShareWebApp.Controllers;

public class BikeController : Controller
{
    private readonly BikeShareDbContext _context;

    public BikeController(BikeShareDbContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Map()
    {
        int? userId = GetCurrentUserId();

        ViewBag.CurrentTrip = null;
        if (userId != null)
        {
            ViewBag.CurrentTrip = await _context.Trips
                .Include(t => t.Bike)
                .FirstOrDefaultAsync(t => t.CustomerId == userId && 
                    (t.TripStatus == "Active" || t.TripStatus == "Paused"));
        }

        var bikes = await _context.Bikes
            .Include(b => b.Station)
            .Include(b => b.SmartLock)
            .Include(b => b.GpsDevice)
            .OrderBy(b => b.BikeCode)
            .ToListAsync();

        return View(bikes);
    }

    public async Task<IActionResult> Detail(int id)
    {
        var bike = await _context.Bikes
            .Include(b => b.Station)
            .Include(b => b.SmartLock)
            .Include(b => b.GpsDevice)
            .FirstOrDefaultAsync(b => b.BikeId == id);

        if (bike == null)
        {
            TempData["Error"] = "Không tìm thấy xe.";
            return RedirectToAction(nameof(Map));
        }

        return View(bike);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Reserve(int bikeId)
    {
        int? userId = GetCurrentUserId();
        if (userId == null)
        {
            TempData["Error"] = "Bạn cần đăng nhập để đặt giữ xe.";
            return RedirectToAction("Login", "Account");
        }

        bool hasActiveTrip = await _context.Trips.AnyAsync(t =>
            t.CustomerId == userId &&
            (t.TripStatus == "Active" || t.TripStatus == "Paused"));

        if (hasActiveTrip)
        {
            TempData["Error"] = "Bạn đang có chuyến đi chưa kết thúc, không thể đặt giữ xe mới.";
            return RedirectToAction("Current", "Trip");
        }

        bool hasActiveReservation = await _context.Reservations.AnyAsync(r =>
            r.CustomerId == userId &&
            r.Status == "Active" &&
            r.ExpiredAt > DateTime.Now);

        if (hasActiveReservation)
        {
            TempData["Error"] = "Bạn đang có một xe được đặt giữ. Vui lòng dùng hoặc hủy trước khi đặt xe khác.";
            return RedirectToAction(nameof(Map));
        }

        var bike = await _context.Bikes.FirstOrDefaultAsync(b => b.BikeId == bikeId);
        if (bike == null)
        {
            TempData["Error"] = "Không tìm thấy xe.";
            return RedirectToAction(nameof(Map));
        }

        if (bike.BikeStatus != "Available")
        {
            TempData["Error"] = "Xe hiện không khả dụng để đặt giữ.";
            return RedirectToAction(nameof(Map));
        }

        var reservation = new Reservation
        {
            CustomerId = userId.Value,
            BikeId = bike.BikeId,
            ReservedAt = DateTime.Now,
            ExpiredAt = DateTime.Now.AddMinutes(15),
            Status = "Active"
        };

        bike.BikeStatus = "Reserved";
        _context.Reservations.Add(reservation);
        await _context.SaveChangesAsync();

        TempData["Success"] = $"Đã đặt giữ xe {bike.BikeCode} trong 15 phút.";
        return RedirectToAction(nameof(Map));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> StartTrip(int bikeId)
    {
        int? userId = GetCurrentUserId();
        if (userId == null)
        {
            TempData["Error"] = "Bạn cần đăng nhập để thuê xe.";
            return RedirectToAction("Login", "Account");
        }

        return await StartTripInternal(userId.Value, bikeId);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> StartByCode(string bikeCode)
    {
        int? userId = GetCurrentUserId();
        if (userId == null)
        {
            TempData["Error"] = "Bạn cần đăng nhập để thuê xe.";
            return RedirectToAction("Login", "Account");
        }

        if (string.IsNullOrWhiteSpace(bikeCode))
        {
            TempData["Error"] = "Vui lòng nhập mã xe hoặc mã QR.";
            return RedirectToAction(nameof(Map));
        }

        string code = bikeCode.Trim();

        var bike = await _context.Bikes
            .FirstOrDefaultAsync(b => b.BikeCode == code || b.QrCode == code);

        if (bike == null)
        {
            TempData["Error"] = "Không tìm thấy xe theo mã vừa nhập.";
            return RedirectToAction(nameof(Map));
        }

        return await StartTripInternal(userId.Value, bike.BikeId);
    }

    public IActionResult Trip()
    {
        return RedirectToAction("Current", "Trip");
    }

    public async Task<IActionResult> History()
    {
        int? userId = GetCurrentUserId();

        var query = _context.Trips
            .Include(t => t.Customer)
            .Include(t => t.Bike)
            .Include(t => t.StartStation)
            .Include(t => t.EndStation)
            .Include(t => t.Invoice)
            .AsQueryable();

        string role = HttpContext.Session.GetString("RoleName") ?? string.Empty;
        if (userId != null && !role.Equals("Admin", StringComparison.OrdinalIgnoreCase))
        {
            query = query.Where(t => t.CustomerId == userId);
        }

        var trips = await query
            .OrderByDescending(t => t.StartTime)
            .ToListAsync();

        return View(trips);
    }

    private async Task<IActionResult> StartTripInternal(int userId, int bikeId)
    {
        bool hasActiveTrip = await _context.Trips.AnyAsync(t =>
            t.CustomerId == userId &&
            (t.TripStatus == "Active" || t.TripStatus == "Paused"));

        if (hasActiveTrip)
        {
            TempData["Error"] = "Bạn đang có chuyến đi chưa kết thúc.";
            return RedirectToAction("Current", "Trip");
        }

        var bike = await _context.Bikes
            .Include(b => b.SmartLock)
            .FirstOrDefaultAsync(b => b.BikeId == bikeId);

        if (bike == null)
        {
            TempData["Error"] = "Không tìm thấy xe.";
            return RedirectToAction(nameof(Map));
        }

        bool isReservedByCurrentUser = await _context.Reservations.AnyAsync(r =>
            r.BikeId == bike.BikeId &&
            r.CustomerId == userId &&
            r.Status == "Active" &&
            r.ExpiredAt > DateTime.Now);

        if (bike.BikeStatus != "Available" && !(bike.BikeStatus == "Reserved" && isReservedByCurrentUser))
        {
            TempData["Error"] = "Xe hiện không khả dụng để thuê.";
            return RedirectToAction(nameof(Map));
        }

        var pricingRule = await _context.PricingRules
            .Where(p => p.IsActive)
            .OrderByDescending(p => p.PricingRuleId)
            .FirstOrDefaultAsync();

        if (pricingRule == null)
        {
            TempData["Error"] = "Chưa có bảng giá đang hoạt động.";
            return RedirectToAction(nameof(Map));
        }

        var wallet = await _context.Wallets.FirstOrDefaultAsync(w => w.CustomerId == userId);
        if (wallet == null)
        {
            wallet = new Wallet
            {
                CustomerId = userId,
                Balance = 0,
                UpdatedAt = DateTime.Now
            };
            _context.Wallets.Add(wallet);
            await _context.SaveChangesAsync();
        }

        var trip = new Trip
        {
            CustomerId = userId,
            BikeId = bike.BikeId,
            StartStationId = bike.StationId,
            PricingRuleId = pricingRule.PricingRuleId,
            StartTime = DateTime.Now,
            DistanceKm = 0,
            TripStatus = "Active"
        };

        bike.BikeStatus = "Rented";
        bike.StationId = null;

        if (bike.SmartLock != null)
        {
            bike.SmartLock.LockStatus = "Unlocked";
            bike.SmartLock.LastSignalAt = DateTime.Now;
        }

        var activeReservations = await _context.Reservations
            .Where(r => r.BikeId == bike.BikeId && r.Status == "Active")
            .ToListAsync();

        foreach (var reservation in activeReservations)
        {
            reservation.Status = reservation.CustomerId == userId ? "Used" : "Cancelled";
        }

        _context.Trips.Add(trip);
        await _context.SaveChangesAsync();

        TempData["Success"] = $"Thuê xe {bike.BikeCode} thành công. Smart Lock đã mở.";
        return RedirectToAction("Current", "Trip");
    }

    private int? GetCurrentUserId()
    {
        return HttpContext.Session.GetInt32("UserId");
    }
}

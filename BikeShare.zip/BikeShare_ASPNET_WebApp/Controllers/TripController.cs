using BikeShareWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BikeShareWebApp.Controllers;

public class TripController : Controller
{
    private readonly BikeShareDbContext _context;

    public TripController(BikeShareDbContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Current()
    {
        int? userId = GetCurrentUserId();
        if (userId == null)
        {
            TempData["Error"] = "Bạn cần đăng nhập để xem chuyến đi.";
            return RedirectToAction("Login", "Account");
        }

        var trip = await GetActiveTrip(userId.Value);

        ViewBag.Stations = await _context.Stations
            .Where(s => s.Status == "Active")
            .OrderBy(s => s.StationName)
            .ToListAsync();

        if (trip != null)
        {
            ViewBag.EstimatedFee = CalculateTripFee(trip, trip.PricingRule);
            ViewBag.ElapsedMinutes = Math.Max(1, (int)Math.Ceiling((DateTime.Now - trip.StartTime).TotalMinutes));
        }

        return View(trip);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Pause(int tripId)
    {
        int? userId = GetCurrentUserId();
        if (userId == null)
        {
            return RedirectToAction("Login", "Account");
        }

        var trip = await _context.Trips
            .Include(t => t.Bike)
            .ThenInclude(b => b!.SmartLock)
            .FirstOrDefaultAsync(t => t.TripId == tripId && t.CustomerId == userId);

        if (trip == null || trip.TripStatus != "Active")
        {
            TempData["Error"] = "Không thể khóa tạm chuyến đi này.";
            return RedirectToAction(nameof(Current));
        }

        trip.TripStatus = "Paused";
        if (trip.Bike != null)
        {
            trip.Bike.BikeStatus = "Paused";
            if (trip.Bike.SmartLock != null)
            {
                trip.Bike.SmartLock.LockStatus = "Locked";
                trip.Bike.SmartLock.LastSignalAt = DateTime.Now;
            }
        }

        await _context.SaveChangesAsync();

        TempData["Success"] = "Đã khóa xe tạm thời. Chuyến đi vẫn tiếp tục tính thời gian.";
        return RedirectToAction(nameof(Current));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Resume(int tripId)
    {
        int? userId = GetCurrentUserId();
        if (userId == null)
        {
            return RedirectToAction("Login", "Account");
        }

        var trip = await _context.Trips
            .Include(t => t.Bike)
            .ThenInclude(b => b!.SmartLock)
            .FirstOrDefaultAsync(t => t.TripId == tripId && t.CustomerId == userId);

        if (trip == null || trip.TripStatus != "Paused")
        {
            TempData["Error"] = "Không thể mở lại chuyến đi này.";
            return RedirectToAction(nameof(Current));
        }

        trip.TripStatus = "Active";
        if (trip.Bike != null)
        {
            trip.Bike.BikeStatus = "Rented";
            if (trip.Bike.SmartLock != null)
            {
                trip.Bike.SmartLock.LockStatus = "Unlocked";
                trip.Bike.SmartLock.LastSignalAt = DateTime.Now;
            }
        }

        await _context.SaveChangesAsync();

        TempData["Success"] = "Đã mở khóa xe và tiếp tục chuyến đi.";
        return RedirectToAction(nameof(Current));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> End(int tripId, int endStationId)
    {
        int? userId = GetCurrentUserId();
        if (userId == null)
        {
            TempData["Error"] = "Bạn cần đăng nhập.";
            return RedirectToAction("Login", "Account");
        }

        var trip = await _context.Trips
            .Include(t => t.Bike)
            .ThenInclude(b => b!.SmartLock)
            .Include(t => t.Bike)
            .ThenInclude(b => b!.GpsDevice)
            .Include(t => t.PricingRule)
            .FirstOrDefaultAsync(t => t.TripId == tripId && t.CustomerId == userId);

        if (trip == null || (trip.TripStatus != "Active" && trip.TripStatus != "Paused"))
        {
            TempData["Error"] = "Không tìm thấy chuyến đi đang hoạt động.";
            return RedirectToAction(nameof(Current));
        }

        var station = await _context.Stations.FirstOrDefaultAsync(s => s.StationId == endStationId && s.Status == "Active");
        if (station == null)
        {
            TempData["Error"] = "Vui lòng chọn trạm trả xe hợp lệ.";
            return RedirectToAction(nameof(Current));
        }

        var wallet = await _context.Wallets.FirstOrDefaultAsync(w => w.CustomerId == userId);
        if (wallet == null)
        {
            wallet = new Wallet
            {
                CustomerId = userId.Value,
                Balance = 0,
                UpdatedAt = DateTime.Now
            };
            _context.Wallets.Add(wallet);
            await _context.SaveChangesAsync();
        }

        int duration = Math.Max(1, (int)Math.Ceiling((DateTime.Now - trip.StartTime).TotalMinutes));
        decimal total = CalculateTripFee(trip, trip.PricingRule);

        if (wallet.Balance < total)
        {
            TempData["Error"] = $"Ví không đủ tiền để kết thúc chuyến đi. Cần {total:N0}đ, hiện có {wallet.Balance:N0}đ. Vui lòng nạp ví trước.";
            return RedirectToAction("Index", "Wallet");
        }

        trip.EndTime = DateTime.Now;
        trip.EndStationId = station.StationId;
        trip.DurationMinutes = duration;
        trip.TotalAmount = total;
        trip.DistanceKm = Math.Round(duration * 0.12m, 2);
        trip.TripStatus = "Completed";

        if (trip.Bike != null)
        {
            trip.Bike.BikeStatus = "Available";
            trip.Bike.StationId = station.StationId;

            if (trip.Bike.SmartLock != null)
            {
                trip.Bike.SmartLock.LockStatus = "Locked";
                trip.Bike.SmartLock.LastSignalAt = DateTime.Now;
            }

            if (trip.Bike.GpsDevice != null)
            {
                trip.Bike.GpsDevice.Latitude = station.Latitude;
                trip.Bike.GpsDevice.Longitude = station.Longitude;
                trip.Bike.GpsDevice.LastSignalAt = DateTime.Now;
            }
        }

        wallet.Balance -= total;
        wallet.UpdatedAt = DateTime.Now;

        var walletTransaction = new WalletTransaction
        {
            WalletId = wallet.WalletId,
            TransactionType = "Payment",
            Amount = total,
            Description = $"Thanh toán chuyến đi #{trip.TripId}",
            CreatedAt = DateTime.Now
        };

        var payment = new Payment
        {
            TripId = trip.TripId,
            CustomerId = userId.Value,
            PaymentMethod = "Wallet",
            Amount = total,
            PaymentStatus = "Success",
            TransactionCode = $"TXN-{DateTime.Now:yyyyMMddHHmmss}-{trip.TripId}",
            PaidAt = DateTime.Now,
            CreatedAt = DateTime.Now
        };

        _context.WalletTransactions.Add(walletTransaction);
        _context.Payments.Add(payment);
        await _context.SaveChangesAsync();

        var invoice = new Invoice
        {
            TripId = trip.TripId,
            PaymentId = payment.PaymentId,
            InvoiceCode = $"INV-{DateTime.Now:yyyyMMddHHmmss}-{trip.TripId}",
            TotalAmount = total,
            IssuedAt = DateTime.Now,
            InvoiceStatus = "Paid"
        };

        _context.Invoices.Add(invoice);
        await _context.SaveChangesAsync();

        TempData["Success"] = $"Đã kết thúc chuyến đi. Tổng phí: {total:N0}đ. Thanh toán ví thành công.";
        return RedirectToAction("History", "Bike");
    }

    [HttpGet]
    public async Task<IActionResult> Review(int tripId)
    {
        int? userId = GetCurrentUserId();
        if (userId == null)
        {
            TempData["Error"] = "Bạn cần đăng nhập để đánh giá.";
            return RedirectToAction("Login", "Account");
        }

        var trip = await _context.Trips
            .Include(t => t.Bike)
            .FirstOrDefaultAsync(t => t.TripId == tripId && t.CustomerId == userId && t.TripStatus == "Completed");

        if (trip == null)
        {
            TempData["Error"] = "Không tìm thấy chuyến đi đã hoàn thành để đánh giá.";
            return RedirectToAction("History", "Bike");
        }

        ViewBag.Trip = trip;
        return View(new Review { TripId = tripId, CustomerId = userId.Value, Rating = 5 });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Review(Review model)
    {
        int? userId = GetCurrentUserId();
        if (userId == null)
        {
            return RedirectToAction("Login", "Account");
        }

        var trip = await _context.Trips
            .FirstOrDefaultAsync(t => t.TripId == model.TripId && t.CustomerId == userId && t.TripStatus == "Completed");

        if (trip == null)
        {
            TempData["Error"] = "Không tìm thấy chuyến đi.";
            return RedirectToAction("History", "Bike");
        }

        bool existed = await _context.Reviews.AnyAsync(r => r.TripId == model.TripId);
        if (existed)
        {
            TempData["Error"] = "Chuyến đi này đã được đánh giá.";
            return RedirectToAction("History", "Bike");
        }

        int rating = Math.Clamp(model.Rating, 1, 5);

        var review = new Review
        {
            TripId = model.TripId,
            CustomerId = userId.Value,
            Rating = rating,
            Comment = model.Comment,
            CreatedAt = DateTime.Now
        };

        _context.Reviews.Add(review);
        await _context.SaveChangesAsync();

        TempData["Success"] = "Cảm ơn bạn đã đánh giá chuyến đi.";
        return RedirectToAction("History", "Bike");
    }

    private async Task<Trip?> GetActiveTrip(int userId)
    {
        return await _context.Trips
            .Include(t => t.Customer)
            .Include(t => t.Bike)
            .ThenInclude(b => b!.SmartLock)
            .Include(t => t.StartStation)
            .Include(t => t.PricingRule)
            .FirstOrDefaultAsync(t => t.CustomerId == userId &&
                (t.TripStatus == "Active" || t.TripStatus == "Paused"));
    }

    private static decimal CalculateTripFee(Trip trip, PricingRule? pricingRule)
    {
        if (pricingRule == null)
        {
            return 0;
        }

        int duration = Math.Max(1, (int)Math.Ceiling((DateTime.Now - trip.StartTime).TotalMinutes));
        int blocks = Math.Max(1, (int)Math.Ceiling(duration / (decimal)pricingRule.BlockMinutes));

        return blocks * pricingRule.PricePerBlock;
    }

    private int? GetCurrentUserId()
    {
        return HttpContext.Session.GetInt32("UserId");
    }
}

using BikeShareWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BikeShareWebApp.Controllers;

public class WalletController : Controller
{
    private readonly BikeShareDbContext _context;

    public WalletController(BikeShareDbContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Index()
    {
        int? userId = HttpContext.Session.GetInt32("UserId");
        if (userId == null)
        {
            TempData["Error"] = "Bạn cần đăng nhập để xem ví.";
            return RedirectToAction("Login", "Account");
        }

        var wallet = await _context.Wallets
            .Include(w => w.WalletTransactions)
            .FirstOrDefaultAsync(w => w.CustomerId == userId);

        if (wallet == null)
        {
            wallet = new Wallet
            {
                CustomerId = userId.Value,
                Balance = 0,
                UpdatedAt = DateTime.Now
            };
            _context.Wallets.Add(wallet);
            await _context.SaveChangesAsync();
        }

        wallet.WalletTransactions = wallet.WalletTransactions
            .OrderByDescending(t => t.CreatedAt)
            .ToList();

        return View(wallet);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> TopUp(decimal amount)
    {
        int? userId = HttpContext.Session.GetInt32("UserId");
        if (userId == null)
        {
            TempData["Error"] = "Bạn cần đăng nhập để nạp ví.";
            return RedirectToAction("Login", "Account");
        }

        if (amount <= 0)
        {
            TempData["Error"] = "Số tiền nạp phải lớn hơn 0.";
            return RedirectToAction(nameof(Index));
        }

        var wallet = await _context.Wallets.FirstOrDefaultAsync(w => w.CustomerId == userId);
        if (wallet == null)
        {
            wallet = new Wallet
            {
                CustomerId = userId.Value,
                Balance = 0,
                UpdatedAt = DateTime.Now
            };
            _context.Wallets.Add(wallet);
            await _context.SaveChangesAsync();
        }

        wallet.Balance += amount;
        wallet.UpdatedAt = DateTime.Now;

        var transaction = new WalletTransaction
        {
            WalletId = wallet.WalletId,
            TransactionType = "TopUp",
            Amount = amount,
            Description = "Nạp tiền ví demo",
            CreatedAt = DateTime.Now
        };

        _context.WalletTransactions.Add(transaction);
        await _context.SaveChangesAsync();

        TempData["Success"] = $"Nạp ví thành công {amount:N0}đ.";
        return RedirectToAction(nameof(Index));
    }
}

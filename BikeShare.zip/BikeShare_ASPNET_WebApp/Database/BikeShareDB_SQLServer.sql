
/*
    DATABASE: BikeShareDB
    Mô tả: CSDL cho hệ thống thuê xe đạp công cộng qua QR Code.
    Hệ quản trị đề xuất: Microsoft SQL Server.
*/

IF DB_ID(N'BikeShareDB') IS NULL
BEGIN
    CREATE DATABASE BikeShareDB;
END
GO

USE BikeShareDB;
GO

/* =========================
   DROP TABLES IF EXISTS
   ========================= */

IF OBJECT_ID(N'dbo.MaintenanceTickets', N'U') IS NOT NULL DROP TABLE dbo.MaintenanceTickets;
IF OBJECT_ID(N'dbo.IssueReports', N'U') IS NOT NULL DROP TABLE dbo.IssueReports;
IF OBJECT_ID(N'dbo.Reviews', N'U') IS NOT NULL DROP TABLE dbo.Reviews;
IF OBJECT_ID(N'dbo.Invoices', N'U') IS NOT NULL DROP TABLE dbo.Invoices;
IF OBJECT_ID(N'dbo.Payments', N'U') IS NOT NULL DROP TABLE dbo.Payments;
IF OBJECT_ID(N'dbo.WalletTransactions', N'U') IS NOT NULL DROP TABLE dbo.WalletTransactions;
IF OBJECT_ID(N'dbo.Wallets', N'U') IS NOT NULL DROP TABLE dbo.Wallets;
IF OBJECT_ID(N'dbo.TripVouchers', N'U') IS NOT NULL DROP TABLE dbo.TripVouchers;
IF OBJECT_ID(N'dbo.Vouchers', N'U') IS NOT NULL DROP TABLE dbo.Vouchers;
IF OBJECT_ID(N'dbo.Trips', N'U') IS NOT NULL DROP TABLE dbo.Trips;
IF OBJECT_ID(N'dbo.Reservations', N'U') IS NOT NULL DROP TABLE dbo.Reservations;
IF OBJECT_ID(N'dbo.Bikes', N'U') IS NOT NULL DROP TABLE dbo.Bikes;
IF OBJECT_ID(N'dbo.SmartLocks', N'U') IS NOT NULL DROP TABLE dbo.SmartLocks;
IF OBJECT_ID(N'dbo.GpsDevices', N'U') IS NOT NULL DROP TABLE dbo.GpsDevices;
IF OBJECT_ID(N'dbo.Stations', N'U') IS NOT NULL DROP TABLE dbo.Stations;
IF OBJECT_ID(N'dbo.PricingRules', N'U') IS NOT NULL DROP TABLE dbo.PricingRules;
IF OBJECT_ID(N'dbo.CustomerProfiles', N'U') IS NOT NULL DROP TABLE dbo.CustomerProfiles;
IF OBJECT_ID(N'dbo.Users', N'U') IS NOT NULL DROP TABLE dbo.Users;
IF OBJECT_ID(N'dbo.Roles', N'U') IS NOT NULL DROP TABLE dbo.Roles;
GO

/* =========================
   1. ROLES
   ========================= */

CREATE TABLE dbo.Roles (
    RoleId INT IDENTITY(1,1) PRIMARY KEY,
    RoleName NVARCHAR(50) NOT NULL UNIQUE,
    Description NVARCHAR(255) NULL
);
GO

/* =========================
   2. USERS
   Dùng chung cho khách hàng, admin, nhân viên kỹ thuật, CSKH...
   ========================= */

CREATE TABLE dbo.Users (
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    RoleId INT NOT NULL,
    FullName NVARCHAR(100) NOT NULL,
    Phone NVARCHAR(20) NOT NULL UNIQUE,
    Email NVARCHAR(100) NULL UNIQUE,
    PasswordHash NVARCHAR(255) NOT NULL,
    Status NVARCHAR(30) NOT NULL DEFAULT N'Active',
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),

    CONSTRAINT FK_Users_Roles
        FOREIGN KEY (RoleId) REFERENCES dbo.Roles(RoleId),

    CONSTRAINT CK_Users_Status
        CHECK (Status IN (N'Pending', N'Active', N'Locked', N'Closed'))
);
GO

/* =========================
   3. CUSTOMER PROFILES
   Hồ sơ định danh của khách thuê xe
   ========================= */

CREATE TABLE dbo.CustomerProfiles (
    CustomerId INT PRIMARY KEY,
    IdentityType NVARCHAR(30) NULL,
    IdentityNumber NVARCHAR(50) NULL,
    IdentityImageUrl NVARCHAR(255) NULL,
    VerifiedStatus NVARCHAR(30) NOT NULL DEFAULT N'NotVerified',
    VerifiedAt DATETIME2 NULL,

    CONSTRAINT FK_CustomerProfiles_Users
        FOREIGN KEY (CustomerId) REFERENCES dbo.Users(UserId),

    CONSTRAINT CK_CustomerProfiles_VerifiedStatus
        CHECK (VerifiedStatus IN (N'NotVerified', N'Pending', N'Verified', N'Rejected'))
);
GO

/* =========================
   4. STATIONS
   Trạm xe
   ========================= */

CREATE TABLE dbo.Stations (
    StationId INT IDENTITY(1,1) PRIMARY KEY,
    StationCode NVARCHAR(30) NOT NULL UNIQUE,
    StationName NVARCHAR(100) NOT NULL,
    Address NVARCHAR(255) NULL,
    Latitude DECIMAL(10,7) NOT NULL,
    Longitude DECIMAL(10,7) NOT NULL,
    Capacity INT NOT NULL,
    Status NVARCHAR(30) NOT NULL DEFAULT N'Active',
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),

    CONSTRAINT CK_Stations_Capacity CHECK (Capacity > 0),
    CONSTRAINT CK_Stations_Status
        CHECK (Status IN (N'Active', N'Inactive', N'Maintenance'))
);
GO

/* =========================
   5. GPS DEVICES
   Thiết bị GPS gắn trên xe
   ========================= */

CREATE TABLE dbo.GpsDevices (
    GpsDeviceId INT IDENTITY(1,1) PRIMARY KEY,
    DeviceCode NVARCHAR(50) NOT NULL UNIQUE,
    Latitude DECIMAL(10,7) NULL,
    Longitude DECIMAL(10,7) NULL,
    LastSignalAt DATETIME2 NULL,
    Status NVARCHAR(30) NOT NULL DEFAULT N'Active',

    CONSTRAINT CK_GpsDevices_Status
        CHECK (Status IN (N'Active', N'Inactive', N'LostSignal', N'Maintenance'))
);
GO

/* =========================
   6. SMART LOCKS
   Khóa thông minh
   ========================= */

CREATE TABLE dbo.SmartLocks (
    SmartLockId INT IDENTITY(1,1) PRIMARY KEY,
    LockCode NVARCHAR(50) NOT NULL UNIQUE,
    LockStatus NVARCHAR(30) NOT NULL DEFAULT N'Locked',
    BatteryPercent INT NOT NULL DEFAULT 100,
    LastSignalAt DATETIME2 NULL,

    CONSTRAINT CK_SmartLocks_Status
        CHECK (LockStatus IN (N'Locked', N'Unlocked', N'Error', N'Offline')),

    CONSTRAINT CK_SmartLocks_Battery
        CHECK (BatteryPercent BETWEEN 0 AND 100)
);
GO

/* =========================
   7. BIKES
   Xe đạp
   ========================= */

CREATE TABLE dbo.Bikes (
    BikeId INT IDENTITY(1,1) PRIMARY KEY,
    BikeCode NVARCHAR(30) NOT NULL UNIQUE,
    QrCode NVARCHAR(100) NOT NULL UNIQUE,
    StationId INT NULL,
    GpsDeviceId INT NULL UNIQUE,
    SmartLockId INT NULL UNIQUE,
    BikeStatus NVARCHAR(30) NOT NULL DEFAULT N'Available',
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),

    CONSTRAINT FK_Bikes_Stations
        FOREIGN KEY (StationId) REFERENCES dbo.Stations(StationId),

    CONSTRAINT FK_Bikes_GpsDevices
        FOREIGN KEY (GpsDeviceId) REFERENCES dbo.GpsDevices(GpsDeviceId),

    CONSTRAINT FK_Bikes_SmartLocks
        FOREIGN KEY (SmartLockId) REFERENCES dbo.SmartLocks(SmartLockId),

    CONSTRAINT CK_Bikes_Status
        CHECK (BikeStatus IN (N'Available', N'Reserved', N'Rented', N'Paused', N'Issue', N'Maintenance', N'Inactive'))
);
GO

/* =========================
   8. PRICING RULES
   Bảng giá thuê
   ========================= */

CREATE TABLE dbo.PricingRules (
    PricingRuleId INT IDENTITY(1,1) PRIMARY KEY,
    RuleName NVARCHAR(100) NOT NULL,
    PricePerBlock DECIMAL(18,2) NOT NULL,
    BlockMinutes INT NOT NULL,
    DepositAmount DECIMAL(18,2) NOT NULL DEFAULT 0,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),

    CONSTRAINT CK_PricingRules_Price CHECK (PricePerBlock >= 0),
    CONSTRAINT CK_PricingRules_Block CHECK (BlockMinutes > 0),
    CONSTRAINT CK_PricingRules_Deposit CHECK (DepositAmount >= 0)
);
GO

/* =========================
   9. RESERVATIONS
   Đặt giữ xe trước
   ========================= */

CREATE TABLE dbo.Reservations (
    ReservationId INT IDENTITY(1,1) PRIMARY KEY,
    CustomerId INT NOT NULL,
    BikeId INT NOT NULL,
    ReservedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    ExpiredAt DATETIME2 NOT NULL,
    Status NVARCHAR(30) NOT NULL DEFAULT N'Active',

    CONSTRAINT FK_Reservations_Customers
        FOREIGN KEY (CustomerId) REFERENCES dbo.Users(UserId),

    CONSTRAINT FK_Reservations_Bikes
        FOREIGN KEY (BikeId) REFERENCES dbo.Bikes(BikeId),

    CONSTRAINT CK_Reservations_Status
        CHECK (Status IN (N'Active', N'Cancelled', N'Expired', N'Used'))
);
GO

/* =========================
   10. TRIPS
   Chuyến đi thuê xe
   ========================= */

CREATE TABLE dbo.Trips (
    TripId INT IDENTITY(1,1) PRIMARY KEY,
    CustomerId INT NOT NULL,
    BikeId INT NOT NULL,
    StartStationId INT NULL,
    EndStationId INT NULL,
    PricingRuleId INT NOT NULL,
    StartTime DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    EndTime DATETIME2 NULL,
    DistanceKm DECIMAL(10,2) NOT NULL DEFAULT 0,
    DurationMinutes INT NULL,
    TotalAmount DECIMAL(18,2) NULL,
    TripStatus NVARCHAR(30) NOT NULL DEFAULT N'Active',

    CONSTRAINT FK_Trips_Customers
        FOREIGN KEY (CustomerId) REFERENCES dbo.Users(UserId),

    CONSTRAINT FK_Trips_Bikes
        FOREIGN KEY (BikeId) REFERENCES dbo.Bikes(BikeId),

    CONSTRAINT FK_Trips_StartStation
        FOREIGN KEY (StartStationId) REFERENCES dbo.Stations(StationId),

    CONSTRAINT FK_Trips_EndStation
        FOREIGN KEY (EndStationId) REFERENCES dbo.Stations(StationId),

    CONSTRAINT FK_Trips_PricingRules
        FOREIGN KEY (PricingRuleId) REFERENCES dbo.PricingRules(PricingRuleId),

    CONSTRAINT CK_Trips_Status
        CHECK (TripStatus IN (N'Active', N'Paused', N'Completed', N'Cancelled', N'PendingConfirmation')),

    CONSTRAINT CK_Trips_Distance CHECK (DistanceKm >= 0)
);
GO

/* =========================
   11. VOUCHERS
   Mã khuyến mãi
   ========================= */

CREATE TABLE dbo.Vouchers (
    VoucherId INT IDENTITY(1,1) PRIMARY KEY,
    VoucherCode NVARCHAR(50) NOT NULL UNIQUE,
    VoucherName NVARCHAR(100) NOT NULL,
    DiscountType NVARCHAR(20) NOT NULL,
    DiscountValue DECIMAL(18,2) NOT NULL,
    MinAmount DECIMAL(18,2) NOT NULL DEFAULT 0,
    StartDate DATETIME2 NOT NULL,
    EndDate DATETIME2 NOT NULL,
    Quantity INT NULL,
    Status NVARCHAR(30) NOT NULL DEFAULT N'Active',

    CONSTRAINT CK_Vouchers_DiscountType
        CHECK (DiscountType IN (N'Percent', N'Amount')),

    CONSTRAINT CK_Vouchers_DiscountValue CHECK (DiscountValue > 0),

    CONSTRAINT CK_Vouchers_Status
        CHECK (Status IN (N'Active', N'Inactive', N'Expired'))
);
GO

CREATE TABLE dbo.TripVouchers (
    TripVoucherId INT IDENTITY(1,1) PRIMARY KEY,
    TripId INT NOT NULL,
    VoucherId INT NOT NULL,
    DiscountAmount DECIMAL(18,2) NOT NULL DEFAULT 0,

    CONSTRAINT FK_TripVouchers_Trips
        FOREIGN KEY (TripId) REFERENCES dbo.Trips(TripId),

    CONSTRAINT FK_TripVouchers_Vouchers
        FOREIGN KEY (VoucherId) REFERENCES dbo.Vouchers(VoucherId),

    CONSTRAINT CK_TripVouchers_DiscountAmount CHECK (DiscountAmount >= 0)
);
GO

/* =========================
   12. WALLETS
   Ví nội bộ BikeShare
   ========================= */

CREATE TABLE dbo.Wallets (
    WalletId INT IDENTITY(1,1) PRIMARY KEY,
    CustomerId INT NOT NULL UNIQUE,
    Balance DECIMAL(18,2) NOT NULL DEFAULT 0,
    UpdatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),

    CONSTRAINT FK_Wallets_Customers
        FOREIGN KEY (CustomerId) REFERENCES dbo.Users(UserId),

    CONSTRAINT CK_Wallets_Balance CHECK (Balance >= 0)
);
GO

CREATE TABLE dbo.WalletTransactions (
    WalletTransactionId INT IDENTITY(1,1) PRIMARY KEY,
    WalletId INT NOT NULL,
    TransactionType NVARCHAR(30) NOT NULL,
    Amount DECIMAL(18,2) NOT NULL,
    Description NVARCHAR(255) NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),

    CONSTRAINT FK_WalletTransactions_Wallets
        FOREIGN KEY (WalletId) REFERENCES dbo.Wallets(WalletId),

    CONSTRAINT CK_WalletTransactions_Type
        CHECK (TransactionType IN (N'TopUp', N'Payment', N'DepositHold', N'DepositRefund', N'Refund')),

    CONSTRAINT CK_WalletTransactions_Amount CHECK (Amount > 0)
);
GO

/* =========================
   13. PAYMENTS
   Thanh toán
   ========================= */

CREATE TABLE dbo.Payments (
    PaymentId INT IDENTITY(1,1) PRIMARY KEY,
    TripId INT NULL,
    CustomerId INT NOT NULL,
    PaymentMethod NVARCHAR(30) NOT NULL,
    Amount DECIMAL(18,2) NOT NULL,
    PaymentStatus NVARCHAR(30) NOT NULL DEFAULT N'Pending',
    TransactionCode NVARCHAR(100) NULL,
    PaidAt DATETIME2 NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),

    CONSTRAINT FK_Payments_Trips
        FOREIGN KEY (TripId) REFERENCES dbo.Trips(TripId),

    CONSTRAINT FK_Payments_Customers
        FOREIGN KEY (CustomerId) REFERENCES dbo.Users(UserId),

    CONSTRAINT CK_Payments_Method
        CHECK (PaymentMethod IN (N'Wallet', N'Momo', N'ZaloPay', N'BankCard', N'BankTransfer')),

    CONSTRAINT CK_Payments_Status
        CHECK (PaymentStatus IN (N'Pending', N'Success', N'Failed', N'Refunded')),

    CONSTRAINT CK_Payments_Amount CHECK (Amount >= 0)
);
GO

/* =========================
   14. INVOICES
   Hóa đơn
   ========================= */

CREATE TABLE dbo.Invoices (
    InvoiceId INT IDENTITY(1,1) PRIMARY KEY,
    TripId INT NOT NULL UNIQUE,
    PaymentId INT NULL,
    InvoiceCode NVARCHAR(50) NOT NULL UNIQUE,
    TotalAmount DECIMAL(18,2) NOT NULL,
    IssuedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    InvoiceStatus NVARCHAR(30) NOT NULL DEFAULT N'Issued',

    CONSTRAINT FK_Invoices_Trips
        FOREIGN KEY (TripId) REFERENCES dbo.Trips(TripId),

    CONSTRAINT FK_Invoices_Payments
        FOREIGN KEY (PaymentId) REFERENCES dbo.Payments(PaymentId),

    CONSTRAINT CK_Invoices_Status
        CHECK (InvoiceStatus IN (N'Issued', N'Paid', N'Cancelled'))
);
GO

/* =========================
   15. ISSUE REPORTS
   Báo hỏng / sự cố xe
   ========================= */

CREATE TABLE dbo.IssueReports (
    IssueReportId INT IDENTITY(1,1) PRIMARY KEY,
    CustomerId INT NOT NULL,
    BikeId INT NOT NULL,
    TripId INT NULL,
    IssueType NVARCHAR(50) NOT NULL,
    Description NVARCHAR(500) NOT NULL,
    ImageUrl NVARCHAR(255) NULL,
    ReportStatus NVARCHAR(30) NOT NULL DEFAULT N'New',
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),

    CONSTRAINT FK_IssueReports_Customers
        FOREIGN KEY (CustomerId) REFERENCES dbo.Users(UserId),

    CONSTRAINT FK_IssueReports_Bikes
        FOREIGN KEY (BikeId) REFERENCES dbo.Bikes(BikeId),

    CONSTRAINT FK_IssueReports_Trips
        FOREIGN KEY (TripId) REFERENCES dbo.Trips(TripId),

    CONSTRAINT CK_IssueReports_Status
        CHECK (ReportStatus IN (N'New', N'Processing', N'Resolved', N'Rejected'))
);
GO

/* =========================
   16. REVIEWS
   Đánh giá chuyến đi
   ========================= */

CREATE TABLE dbo.Reviews (
    ReviewId INT IDENTITY(1,1) PRIMARY KEY,
    TripId INT NOT NULL UNIQUE,
    CustomerId INT NOT NULL,
    Rating INT NOT NULL,
    Comment NVARCHAR(500) NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),

    CONSTRAINT FK_Reviews_Trips
        FOREIGN KEY (TripId) REFERENCES dbo.Trips(TripId),

    CONSTRAINT FK_Reviews_Customers
        FOREIGN KEY (CustomerId) REFERENCES dbo.Users(UserId),

    CONSTRAINT CK_Reviews_Rating CHECK (Rating BETWEEN 1 AND 5)
);
GO

/* =========================
   17. MAINTENANCE TICKETS
   Phiếu bảo trì xe
   ========================= */

CREATE TABLE dbo.MaintenanceTickets (
    MaintenanceTicketId INT IDENTITY(1,1) PRIMARY KEY,
    BikeId INT NOT NULL,
    IssueReportId INT NULL,
    StaffId INT NULL,
    Description NVARCHAR(500) NOT NULL,
    MaintenanceStatus NVARCHAR(30) NOT NULL DEFAULT N'Open',
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    CompletedAt DATETIME2 NULL,

    CONSTRAINT FK_MaintenanceTickets_Bikes
        FOREIGN KEY (BikeId) REFERENCES dbo.Bikes(BikeId),

    CONSTRAINT FK_MaintenanceTickets_IssueReports
        FOREIGN KEY (IssueReportId) REFERENCES dbo.IssueReports(IssueReportId),

    CONSTRAINT FK_MaintenanceTickets_Staff
        FOREIGN KEY (StaffId) REFERENCES dbo.Users(UserId),

    CONSTRAINT CK_MaintenanceTickets_Status
        CHECK (MaintenanceStatus IN (N'Open', N'InProgress', N'Done', N'Cancelled'))
);
GO

/* =========================
   INDEXES
   ========================= */

CREATE INDEX IX_Bikes_Status ON dbo.Bikes(BikeStatus);
CREATE INDEX IX_Bikes_StationId ON dbo.Bikes(StationId);
CREATE INDEX IX_Trips_CustomerId ON dbo.Trips(CustomerId);
CREATE INDEX IX_Trips_BikeId ON dbo.Trips(BikeId);
CREATE INDEX IX_Trips_Status ON dbo.Trips(TripStatus);
CREATE INDEX IX_Payments_CustomerId ON dbo.Payments(CustomerId);
CREATE INDEX IX_IssueReports_BikeId ON dbo.IssueReports(BikeId);
GO

/* =========================
   SEED DATA
   ========================= */

INSERT INTO dbo.Roles (RoleName, Description)
VALUES
(N'Customer', N'Khách thuê xe'),
(N'Admin', N'Quản trị viên hệ thống'),
(N'Technician', N'Nhân viên kỹ thuật/bảo trì'),
(N'Dispatcher', N'Nhân viên điều phối'),
(N'CustomerSupport', N'Nhân viên chăm sóc khách hàng'),
(N'Marketing', N'Nhân viên marketing'),
(N'Accountant', N'Nhân viên kế toán'),
(N'Director', N'Ban giám đốc');
GO

INSERT INTO dbo.Users (RoleId, FullName, Phone, Email, PasswordHash, Status)
VALUES
(1, N'Nguyễn Văn An', N'0901000001', N'an@gmail.com', N'123456', N'Active'),
(1, N'Trần Thị Bình', N'0901000002', N'binh@gmail.com', N'123456', N'Active'),
(2, N'Quản Trị Viên', N'0901000003', N'admin@bikeshare.vn', N'admin123', N'Active'),
(3, N'Nhân Viên Kỹ Thuật', N'0901000004', N'tech@bikeshare.vn', N'tech123', N'Active');
GO

INSERT INTO dbo.CustomerProfiles (CustomerId, IdentityType, IdentityNumber, VerifiedStatus)
VALUES
(1, N'CCCD', N'079200000001', N'Verified'),
(2, N'CCCD', N'079200000002', N'Pending');
GO

INSERT INTO dbo.Wallets (CustomerId, Balance)
VALUES
(1, 200000),
(2, 100000);
GO

INSERT INTO dbo.Stations (StationCode, StationName, Address, Latitude, Longitude, Capacity, Status)
VALUES
(N'ST001', N'Trạm HUFLIT', N'828 Sư Vạn Hạnh, Quận 10, TP.HCM', 10.7758430, 106.6670370, 30, N'Active'),
(N'ST002', N'Trạm Công viên Lê Thị Riêng', N'Quận 10, TP.HCM', 10.7860100, 106.6669500, 25, N'Active'),
(N'ST003', N'Trạm Ký túc xá', N'Quận 10, TP.HCM', 10.7812000, 106.6701000, 20, N'Active');
GO

INSERT INTO dbo.GpsDevices (DeviceCode, Latitude, Longitude, LastSignalAt, Status)
VALUES
(N'GPS001', 10.7758430, 106.6670370, SYSDATETIME(), N'Active'),
(N'GPS002', 10.7860100, 106.6669500, SYSDATETIME(), N'Active'),
(N'GPS003', 10.7812000, 106.6701000, SYSDATETIME(), N'Active');
GO

INSERT INTO dbo.SmartLocks (LockCode, LockStatus, BatteryPercent, LastSignalAt)
VALUES
(N'LOCK001', N'Locked', 95, SYSDATETIME()),
(N'LOCK002', N'Locked', 87, SYSDATETIME()),
(N'LOCK003', N'Locked', 76, SYSDATETIME());
GO

INSERT INTO dbo.Bikes (BikeCode, QrCode, StationId, GpsDeviceId, SmartLockId, BikeStatus)
VALUES
(N'BS-001', N'QR-BS-001', 1, 1, 1, N'Available'),
(N'BS-002', N'QR-BS-002', 1, 2, 2, N'Available'),
(N'BS-003', N'QR-BS-003', 2, 3, 3, N'Maintenance');
GO

INSERT INTO dbo.PricingRules (RuleName, PricePerBlock, BlockMinutes, DepositAmount, IsActive)
VALUES
(N'Gói cơ bản - 4.000đ / 10 phút', 4000, 10, 50000, 1);
GO

INSERT INTO dbo.Vouchers (VoucherCode, VoucherName, DiscountType, DiscountValue, MinAmount, StartDate, EndDate, Quantity, Status)
VALUES
(N'WELCOME10', N'Giảm 10% cho khách mới', N'Percent', 10, 10000, SYSDATETIME(), DATEADD(MONTH, 3, SYSDATETIME()), 100, N'Active');
GO

/* Dữ liệu mẫu một chuyến đi đã hoàn thành */
INSERT INTO dbo.Trips
(CustomerId, BikeId, StartStationId, EndStationId, PricingRuleId, StartTime, EndTime, DistanceKm, DurationMinutes, TotalAmount, TripStatus)
VALUES
(1, 1, 1, 2, 1, DATEADD(MINUTE, -25, SYSDATETIME()), SYSDATETIME(), 2.40, 25, 12000, N'Completed');
GO

INSERT INTO dbo.Payments
(TripId, CustomerId, PaymentMethod, Amount, PaymentStatus, TransactionCode, PaidAt)
VALUES
(1, 1, N'Wallet', 12000, N'Success', N'TXN-DEMO-001', SYSDATETIME());
GO

INSERT INTO dbo.Invoices
(TripId, PaymentId, InvoiceCode, TotalAmount, InvoiceStatus)
VALUES
(1, 1, N'INV-DEMO-001', 12000, N'Paid');
GO

INSERT INTO dbo.Reviews
(TripId, CustomerId, Rating, Comment)
VALUES
(1, 1, 5, N'Xe chạy tốt, ứng dụng dễ sử dụng.');
GO

/* =========================
   SAMPLE SELECTS
   ========================= */

SELECT * FROM dbo.Stations;
SELECT * FROM dbo.Bikes;
SELECT * FROM dbo.Trips;
SELECT * FROM dbo.Payments;
GO

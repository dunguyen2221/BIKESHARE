USE BikeShareDB;
GO

-- Chạy file này nếu database của bạn đang dùng mật khẩu mẫu cũ dạng *_HASH_DEMO.
-- Sau khi chạy, có thể đăng nhập:
-- Customer: an@gmail.com / 123456
-- Admin: admin@bikeshare.vn / admin123
-- Technician: tech@bikeshare.vn / tech123

UPDATE dbo.Users
SET PasswordHash = N'123456'
WHERE Email IN (N'an@gmail.com', N'binh@gmail.com');

UPDATE dbo.Users
SET PasswordHash = N'admin123'
WHERE Email = N'admin@bikeshare.vn';

UPDATE dbo.Users
SET PasswordHash = N'tech123'
WHERE Email = N'tech@bikeshare.vn';

SELECT UserId, FullName, Email, Phone, PasswordHash, Status
FROM dbo.Users
ORDER BY UserId;
GO

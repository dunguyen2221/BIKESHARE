using System.ComponentModel.DataAnnotations;

namespace BikeShareWebApp.Models;

public class Reservation
{
    [Key]
    public int ReservationId { get; set; }

    public int CustomerId { get; set; }
    public int BikeId { get; set; }

    public DateTime ReservedAt { get; set; } = DateTime.Now;
    public DateTime ExpiredAt { get; set; }

    [Required, StringLength(30)]
    public string Status { get; set; } = "Active";

    public User? Customer { get; set; }
    public Bike? Bike { get; set; }
}

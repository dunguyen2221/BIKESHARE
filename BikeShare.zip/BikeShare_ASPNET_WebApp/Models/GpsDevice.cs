using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BikeShareWebApp.Models;

public class GpsDevice
{
    [Key]
    public int GpsDeviceId { get; set; }

    [Required, StringLength(50)]
    public string DeviceCode { get; set; } = string.Empty;

    [Column(TypeName = "decimal(10,7)")]
    public decimal? Latitude { get; set; }

    [Column(TypeName = "decimal(10,7)")]
    public decimal? Longitude { get; set; }

    public DateTime? LastSignalAt { get; set; }

    [Required, StringLength(30)]
    public string Status { get; set; } = "Active";

    public Bike? Bike { get; set; }
}

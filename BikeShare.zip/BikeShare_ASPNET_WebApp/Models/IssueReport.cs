using System.ComponentModel.DataAnnotations;

namespace BikeShareWebApp.Models;

public class IssueReport
{
    [Key]
    public int IssueReportId { get; set; }

    public int CustomerId { get; set; }
    public int BikeId { get; set; }
    public int? TripId { get; set; }

    [Required, StringLength(50)]
    public string IssueType { get; set; } = string.Empty;

    [Required, StringLength(500)]
    public string Description { get; set; } = string.Empty;

    [StringLength(255)]
    public string? ImageUrl { get; set; }

    [Required, StringLength(30)]
    public string ReportStatus { get; set; } = "New";

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public User? Customer { get; set; }
    public Bike? Bike { get; set; }
    public Trip? Trip { get; set; }
}

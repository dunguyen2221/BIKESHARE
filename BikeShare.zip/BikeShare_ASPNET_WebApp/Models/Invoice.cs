using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BikeShareWebApp.Models;

public class Invoice
{
    [Key]
    public int InvoiceId { get; set; }

    public int TripId { get; set; }
    public int? PaymentId { get; set; }

    [Required, StringLength(50)]
    public string InvoiceCode { get; set; } = string.Empty;

    [Column(TypeName = "decimal(18,2)")]
    public decimal TotalAmount { get; set; }

    public DateTime IssuedAt { get; set; } = DateTime.Now;

    [Required, StringLength(30)]
    public string InvoiceStatus { get; set; } = "Issued";

    public Trip? Trip { get; set; }
    public Payment? Payment { get; set; }
}

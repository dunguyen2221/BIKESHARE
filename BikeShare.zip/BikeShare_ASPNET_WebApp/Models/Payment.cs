using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BikeShareWebApp.Models;

public class Payment
{
    [Key]
    public int PaymentId { get; set; }

    public int? TripId { get; set; }
    public int CustomerId { get; set; }

    [Required, StringLength(30)]
    public string PaymentMethod { get; set; } = "Wallet";

    [Column(TypeName = "decimal(18,2)")]
    public decimal Amount { get; set; }

    [Required, StringLength(30)]
    public string PaymentStatus { get; set; } = "Pending";

    [StringLength(100)]
    public string? TransactionCode { get; set; }

    public DateTime? PaidAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public Trip? Trip { get; set; }
    public User? Customer { get; set; }
    public Invoice? Invoice { get; set; }
}

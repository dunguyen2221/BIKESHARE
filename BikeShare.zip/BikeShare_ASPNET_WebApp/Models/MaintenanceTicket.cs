using System.ComponentModel.DataAnnotations;

namespace BikeShareWebApp.Models;

public class MaintenanceTicket
{
    [Key]
    public int MaintenanceTicketId { get; set; }

    public int BikeId { get; set; }
    public int? IssueReportId { get; set; }
    public int? StaffId { get; set; }

    [Required, StringLength(500)]
    public string Description { get; set; } = string.Empty;

    [Required, StringLength(30)]
    public string MaintenanceStatus { get; set; } = "Open";

    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime? CompletedAt { get; set; }

    public Bike? Bike { get; set; }
    public IssueReport? IssueReport { get; set; }
    public User? Staff { get; set; }
}

using System.ComponentModel.DataAnnotations;

namespace BikeShareWebApp.Models;

public class Role
{
    [Key]
    public int RoleId { get; set; }

    [Required, StringLength(50)]
    public string RoleName { get; set; } = string.Empty;

    [StringLength(255)]
    public string? Description { get; set; }

    public ICollection<User> Users { get; set; } = new List<User>();
}

using Microsoft.EntityFrameworkCore;

namespace BikeShareWebApp.Models;

public class BikeShareDbContext : DbContext
{
    public BikeShareDbContext(DbContextOptions<BikeShareDbContext> options) : base(options)
    {
    }

    public DbSet<Role> Roles => Set<Role>();
    public DbSet<User> Users => Set<User>();
    public DbSet<CustomerProfile> CustomerProfiles => Set<CustomerProfile>();
    public DbSet<Station> Stations => Set<Station>();
    public DbSet<GpsDevice> GpsDevices => Set<GpsDevice>();
    public DbSet<SmartLock> SmartLocks => Set<SmartLock>();
    public DbSet<Bike> Bikes => Set<Bike>();
    public DbSet<PricingRule> PricingRules => Set<PricingRule>();
    public DbSet<Reservation> Reservations => Set<Reservation>();
    public DbSet<Trip> Trips => Set<Trip>();
    public DbSet<Voucher> Vouchers => Set<Voucher>();
    public DbSet<Wallet> Wallets => Set<Wallet>();
    public DbSet<WalletTransaction> WalletTransactions => Set<WalletTransaction>();
    public DbSet<Payment> Payments => Set<Payment>();
    public DbSet<Invoice> Invoices => Set<Invoice>();
    public DbSet<IssueReport> IssueReports => Set<IssueReport>();
    public DbSet<Review> Reviews => Set<Review>();
    public DbSet<MaintenanceTicket> MaintenanceTickets => Set<MaintenanceTicket>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<User>()
            .HasIndex(u => u.Phone)
            .IsUnique();

        modelBuilder.Entity<User>()
            .HasIndex(u => u.Email)
            .IsUnique()
            .HasFilter("[Email] IS NOT NULL");

        modelBuilder.Entity<User>()
            .HasOne(u => u.Role)
            .WithMany(r => r.Users)
            .HasForeignKey(u => u.RoleId);

        modelBuilder.Entity<CustomerProfile>()
            .HasOne(cp => cp.Customer)
            .WithOne(u => u.CustomerProfile)
            .HasForeignKey<CustomerProfile>(cp => cp.CustomerId);

        modelBuilder.Entity<Wallet>()
            .HasOne(w => w.Customer)
            .WithOne(u => u.Wallet)
            .HasForeignKey<Wallet>(w => w.CustomerId);

        modelBuilder.Entity<Bike>()
            .HasOne(b => b.Station)
            .WithMany(s => s.Bikes)
            .HasForeignKey(b => b.StationId);

        modelBuilder.Entity<Bike>()
            .HasOne(b => b.GpsDevice)
            .WithOne(g => g.Bike)
            .HasForeignKey<Bike>(b => b.GpsDeviceId);

        modelBuilder.Entity<Bike>()
            .HasOne(b => b.SmartLock)
            .WithOne(s => s.Bike)
            .HasForeignKey<Bike>(b => b.SmartLockId);

        modelBuilder.Entity<Trip>()
            .HasOne(t => t.Customer)
            .WithMany(u => u.Trips)
            .HasForeignKey(t => t.CustomerId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Trip>()
            .HasOne(t => t.Bike)
            .WithMany(b => b.Trips)
            .HasForeignKey(t => t.BikeId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Trip>()
            .HasOne(t => t.StartStation)
            .WithMany()
            .HasForeignKey(t => t.StartStationId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Trip>()
            .HasOne(t => t.EndStation)
            .WithMany()
            .HasForeignKey(t => t.EndStationId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Trip>()
            .HasOne(t => t.PricingRule)
            .WithMany(p => p.Trips)
            .HasForeignKey(t => t.PricingRuleId);

        modelBuilder.Entity<Payment>()
            .HasOne(p => p.Trip)
            .WithOne(t => t.Payment)
            .HasForeignKey<Payment>(p => p.TripId);

        modelBuilder.Entity<Invoice>()
            .HasOne(i => i.Trip)
            .WithOne(t => t.Invoice)
            .HasForeignKey<Invoice>(i => i.TripId);

        modelBuilder.Entity<Review>()
            .HasOne(r => r.Trip)
            .WithOne(t => t.Review)
            .HasForeignKey<Review>(r => r.TripId);
    }
}

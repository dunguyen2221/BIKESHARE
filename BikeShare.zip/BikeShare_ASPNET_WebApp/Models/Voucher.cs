using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BikeShareWebApp.Models;

public class Voucher
{
    [Key]
    public int VoucherId { get; set; }

    [Required, StringLength(50)]
    public string VoucherCode { get; set; } = string.Empty;

    [Required, StringLength(100)]
    public string VoucherName { get; set; } = string.Empty;

    [Required, StringLength(20)]
    public string DiscountType { get; set; } = "Percent";

    [Column(TypeName = "decimal(18,2)")]
    public decimal DiscountValue { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal MinAmount { get; set; }

    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }

    public int? Quantity { get; set; }

    [Required, StringLength(30)]
    public string Status { get; set; } = "Active";
}

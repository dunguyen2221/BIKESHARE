using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BikeShareWebApp.Models;

public class User
{
    [Key]
    public int UserId { get; set; }

    public int RoleId { get; set; }

    [Required, StringLength(100)]
    public string FullName { get; set; } = string.Empty;

    [Required, StringLength(20)]
    public string Phone { get; set; } = string.Empty;

    [StringLength(100)]
    public string? Email { get; set; }

    [Required, StringLength(255)]
    public string PasswordHash { get; set; } = string.Empty;

    [Required, StringLength(30)]
    public string Status { get; set; } = "Active";

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public Role? Role { get; set; }
    public CustomerProfile? CustomerProfile { get; set; }
    public Wallet? Wallet { get; set; }

    [InverseProperty(nameof(Trip.Customer))]
    public ICollection<Trip> Trips { get; set; } = new List<Trip>();
}

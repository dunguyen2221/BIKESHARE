using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BikeShareWebApp.Models;

public class Station
{
    [Key]
    public int StationId { get; set; }

    [Required, StringLength(30)]
    public string StationCode { get; set; } = string.Empty;

    [Required, StringLength(100)]
    public string StationName { get; set; } = string.Empty;

    [StringLength(255)]
    public string? Address { get; set; }

    [Column(TypeName = "decimal(10,7)")]
    public decimal Latitude { get; set; }

    [Column(TypeName = "decimal(10,7)")]
    public decimal Longitude { get; set; }

    public int Capacity { get; set; }

    [Required, StringLength(30)]
    public string Status { get; set; } = "Active";

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public ICollection<Bike> Bikes { get; set; } = new List<Bike>();
}

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BikeShareWebApp.Models;

public class Trip
{
    [Key]
    public int TripId { get; set; }

    public int CustomerId { get; set; }
    public int BikeId { get; set; }
    public int? StartStationId { get; set; }
    public int? EndStationId { get; set; }
    public int PricingRuleId { get; set; }

    public DateTime StartTime { get; set; } = DateTime.Now;
    public DateTime? EndTime { get; set; }

    [Column(TypeName = "decimal(10,2)")]
    public decimal DistanceKm { get; set; }

    public int? DurationMinutes { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal? TotalAmount { get; set; }

    [Required, StringLength(30)]
    public string TripStatus { get; set; } = "Active";

    public User? Customer { get; set; }
    public Bike? Bike { get; set; }
    public Station? StartStation { get; set; }
    public Station? EndStation { get; set; }
    public PricingRule? PricingRule { get; set; }
    public Payment? Payment { get; set; }
    public Invoice? Invoice { get; set; }
    public Review? Review { get; set; }
}

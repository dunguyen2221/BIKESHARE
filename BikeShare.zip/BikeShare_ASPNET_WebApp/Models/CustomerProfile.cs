using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BikeShareWebApp.Models;

public class CustomerProfile
{
    [Key, ForeignKey(nameof(Customer))]
    public int CustomerId { get; set; }

    [StringLength(30)]
    public string? IdentityType { get; set; }

    [StringLength(50)]
    public string? IdentityNumber { get; set; }

    [StringLength(255)]
    public string? IdentityImageUrl { get; set; }

    [Required, StringLength(30)]
    public string VerifiedStatus { get; set; } = "NotVerified";

    public DateTime? VerifiedAt { get; set; }

    public User? Customer { get; set; }
}

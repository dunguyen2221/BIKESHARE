using System.ComponentModel.DataAnnotations;

namespace BikeShareWebApp.Models;

public class SmartLock
{
    [Key]
    public int SmartLockId { get; set; }

    [Required, StringLength(50)]
    public string LockCode { get; set; } = string.Empty;

    [Required, StringLength(30)]
    public string LockStatus { get; set; } = "Locked";

    public int BatteryPercent { get; set; } = 100;

    public DateTime? LastSignalAt { get; set; }

    public Bike? Bike { get; set; }
}

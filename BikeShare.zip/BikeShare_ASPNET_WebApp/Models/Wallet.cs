using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BikeShareWebApp.Models;

public class Wallet
{
    [Key]
    public int WalletId { get; set; }

    public int CustomerId { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal Balance { get; set; }

    public DateTime UpdatedAt { get; set; } = DateTime.Now;

    public User? Customer { get; set; }
    public ICollection<WalletTransaction> WalletTransactions { get; set; } = new List<WalletTransaction>();
}

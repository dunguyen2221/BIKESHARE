using System.ComponentModel.DataAnnotations;

namespace BikeShareWebApp.Models;

public class Bike
{
    [Key]
    public int BikeId { get; set; }

    [Required, StringLength(30)]
    public string BikeCode { get; set; } = string.Empty;

    [Required, StringLength(100)]
    public string QrCode { get; set; } = string.Empty;

    public int? StationId { get; set; }
    public int? GpsDeviceId { get; set; }
    public int? SmartLockId { get; set; }

    [Required, StringLength(30)]
    public string BikeStatus { get; set; } = "Available";

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public Station? Station { get; set; }
    public GpsDevice? GpsDevice { get; set; }
    public SmartLock? SmartLock { get; set; }

    public ICollection<Trip> Trips { get; set; } = new List<Trip>();
}

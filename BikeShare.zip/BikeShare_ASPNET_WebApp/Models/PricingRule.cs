using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BikeShareWebApp.Models;

public class PricingRule
{
    [Key]
    public int PricingRuleId { get; set; }

    [Required, StringLength(100)]
    public string RuleName { get; set; } = string.Empty;

    [Column(TypeName = "decimal(18,2)")]
    public decimal PricePerBlock { get; set; }

    public int BlockMinutes { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal DepositAmount { get; set; }

    public bool IsActive { get; set; } = true;

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public ICollection<Trip> Trips { get; set; } = new List<Trip>();
}

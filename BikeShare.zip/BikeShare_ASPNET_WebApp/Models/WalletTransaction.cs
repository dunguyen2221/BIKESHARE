using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BikeShareWebApp.Models;

public class WalletTransaction
{
    [Key]
    public int WalletTransactionId { get; set; }

    public int WalletId { get; set; }

    [Required, StringLength(30)]
    public string TransactionType { get; set; } = string.Empty;

    [Column(TypeName = "decimal(18,2)")]
    public decimal Amount { get; set; }

    [StringLength(255)]
    public string? Description { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public Wallet? Wallet { get; set; }
}

using System.ComponentModel.DataAnnotations;

namespace BikeShareWebApp.Models;

public class Review
{
    [Key]
    public int ReviewId { get; set; }

    public int TripId { get; set; }
    public int CustomerId { get; set; }

    public int Rating { get; set; }

    [StringLength(500)]
    public string? Comment { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public Trip? Trip { get; set; }
    public User? Customer { get; set; }
}
